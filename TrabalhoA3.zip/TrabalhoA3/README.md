# Java GUI crud with MYSQL Database XAMPP

## Simple Project step by step using mysql database and Netbeans IDE


version: 1.0.0

## TECHNOLOGIES

1. Java
1. Swing
1. Java JFrame


## Full Tutorial

[On Youtube](https://youtu.be/9aQb6CWYQ0E)

## Authors

[Elias Abdurrahman](https://github.com/codingWithElias)
